package com.example.navigation_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
